<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'u814958138_iwood');

/** MySQL database username */
define('DB_USER', 'u814958138_mihai');

/** MySQL database password */
define('DB_PASSWORD', 'QQqq2222');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'qow)]zw-}*_V6@p|a<K%a}_6rl{bjQ4DCQ7gC}@S@evJaCuLIQ$F$gQ8YY;|:%p`');
define('SECURE_AUTH_KEY',  'L]MD+,%1iZ )I}<i8=kd>ILO5)e^0yeE7Kziz;l(!yRqXFLIrhf/U+EVmo#e}PH.');
define('LOGGED_IN_KEY',    'UDa55aRu=c&%S-<JIAtz,vekt~ijE+UWZ9=a5#}c+(oF4H+5Y$pD)fq6jDF$nhe@');
define('NONCE_KEY',        ':d482Fenkcyy-1w$m,(pX>TUj-}9]n){R;DHO18:X5>NFexq5>q7TZvFR|a`Bl3-');
define('AUTH_SALT',        '*Z)fl8%NQ8z}$())IiaS1-CAD-g! |r+|-M:k_]c@92-FJL=YR0=q<SK/sG}8XX`');
define('SECURE_AUTH_SALT', '<;_F>x)Nhu}ghT}-Nd;HBA/H@&]qT87`AM7TuznUh61)y|j({sY[-]&-y&5a0c?x');
define('LOGGED_IN_SALT',   '98h4biEJ;Eb(o}1:w@m^zUe-X?D[N+mMsXB/2ufW~ZS&$PiLApk@,`2K)9=EafG9');
define('NONCE_SALT',       '-zHCKQ-C53nm*E-l1lC+;-klT3x=ns)s_4$U N%|*-k;|2M}H+5.=fq*?;mH57+9');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
